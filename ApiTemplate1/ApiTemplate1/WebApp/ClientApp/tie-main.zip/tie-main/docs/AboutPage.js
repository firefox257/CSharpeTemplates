const css = `


`;
const html = `
<div>
	<span class = "title">Tie Lib</span> <br/>
	<comp tietype = "frame" color="ok">
		A minimal library for simple components. <br/>
	</comp><br/><br/>
	<comp tietype="frame" color="error">
		Still being worked on.
	</comp>
</div>
`;


function AboutPage()
{
	var at = 
	{
		
		
	};
	
	return at;
}
AboutPage.css= css;
AboutPage.html = html;

$.comp("AboutPage", AboutPage);


