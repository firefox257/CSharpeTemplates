#ifndef CALLFUNC_CPP
#define CALLFUNC_CPP

var callVoidFunc0(VarRef & r, var a1 = var(), var a2 = var(), var a3 = var(), var a4 = var(), var a5 = var(),
var a6 = var(), var a7 = var(), var a8 = var(), var a9 = var(), var a10 = var())
{
  (*((function<void()>*)r.data))();
  return var();
}
var callVoidFunc1(VarRef & r, var a1 = var(), var a2 = var(), var a3 = var(), var a4 = var(), var a5 = var(),
var a6 = var(), var a7 = var(), var a8 = var(), var a9 = var(), var a10 = var())
{
  (*((function<void(var)>*)r.data))(a1);
  return var();
}
var callVoidFunc2(VarRef & r, var a1 = var(), var a2 = var(), var a3 = var(), var a4 = var(), var a5 = var(),
var a6 = var(), var a7 = var(), var a8 = var(), var a9 = var(), var a10 = var())
{
  (*((function<void(var, var)>*)r.data))(a1, a2);
  return var();
}
var callVoidFunc3(VarRef & r, var a1 = var(), var a2 = var(), var a3 = var(), var a4 = var(), var a5 = var(),
var a6 = var(), var a7 = var(), var a8 = var(), var a9 = var(), var a10 = var())
{
  (*((function<void(var, var, var)>*)r.data))(a1, a2, a3);
  return var();
}
var callVoidFunc4(VarRef & r, var a1 = var(), var a2 = var(), var a3 = var(), var a4 = var(), var a5 = var(),
var a6 = var(), var a7 = var(), var a8 = var(), var a9 = var(), var a10 = var())
{
  (*((function<void(var, var, var, var)>*)r.data))(a1, a2, a3, a4);
  return var();
}
var callVoidFunc5(VarRef & r, var a1 = var(), var a2 = var(), var a3 = var(), var a4 = var(), var a5 = var(),
var a6 = var(), var a7 = var(), var a8 = var(), var a9 = var(), var a10 = var())
{
  (*((function<void(var, var, var, var, var)>*)r.data))(a1, a2, a3, a4, a5);
  return var();
}
var callVoidFunc6(VarRef & r, var a1 = var(), var a2 = var(), var a3 = var(), var a4 = var(), var a5 = var(),
var a6 = var(), var a7 = var(), var a8 = var(), var a9 = var(), var a10 = var())
{
  (*((function<void(var, var, var, var, var, var)>*)r.data))(a1, a2, a3, a4, a5, a6);
  return var();
}
var callVoidFunc7(VarRef & r, var a1 = var(), var a2 = var(), var a3 = var(), var a4 = var(), var a5 = var(),
var a6 = var(), var a7 = var(), var a8 = var(), var a9 = var(), var a10 = var())
{
  (*((function<void(var, var, var, var, var, var, var)>*)r.data))(a1, a2, a3, a4, a5, a6, a7);
  return var();
}
var callVoidFunc8(VarRef & r, var a1 = var(), var a2 = var(), var a3 = var(), var a4 = var(), var a5 = var(),
var a6 = var(), var a7 = var(), var a8 = var(), var a9 = var(), var a10 = var())
{
  (*((function<void(var, var, var, var, var, var, var, var)>*)r.data))(a1, a2, a3, a4, a5, a6, a7, a8);
  return var();
}
var callVoidFunc9(VarRef & r, var a1 = var(), var a2 = var(), var a3 = var(), var a4 = var(), var a5 = var(),
var a6 = var(), var a7 = var(), var a8 = var(), var a9 = var(), var a10 = var())
{
  (*((function<void(var, var, var, var, var, var, var, var, var)>*)r.data))(a1, a2, a3, a4, a5, a6, a7, a8, a9);
  return var();
}
var callVoidFunc10(VarRef & r, var a1 = var(), var a2 = var(), var a3 = var(), var a4 = var(), var a5 = var(),
var a6 = var(), var a7 = var(), var a8 = var(), var a9 = var(), var a10 = var())
{
  (*((function<void(var, var, var, var, var, var, var, var, var, var)>*)r.data))(a1, a2, a3, a4, a5, a6, a7, a8, a9, a10);
  return var();
}
///vars
var callVarFunc0(VarRef & r, var a1 = var(), var a2 = var(), var a3 = var(), var a4 = var(), var a5 = var(),
var a6 = var(), var a7 = var(), var a8 = var(), var a9 = var(), var a10 = var())
{
  return (*((function<var()>*)r.data))();
}
var callVarFunc1(VarRef & r, var a1 = var(), var a2 = var(), var a3 = var(), var a4 = var(), var a5 = var(),
var a6 = var(), var a7 = var(), var a8 = var(), var a9 = var(), var a10 = var())
{
  return (*((function<var(var)>*)r.data))(a1);
}
var callVarFunc2(VarRef & r, var a1 = var(), var a2 = var(), var a3 = var(), var a4 = var(), var a5 = var(),
var a6 = var(), var a7 = var(), var a8 = var(), var a9 = var(), var a10 = var())
{
  return (*((function<var(var, var)>*)r.data))(a1, a2);
}
var callVarFunc3(VarRef & r, var a1 = var(), var a2 = var(), var a3 = var(), var a4 = var(), var a5 = var(),
var a6 = var(), var a7 = var(), var a8 = var(), var a9 = var(), var a10 = var())
{
  return (*((function<var(var, var, var)>*)r.data))(a1, a2, a3);
}
var callVarFunc4(VarRef & r, var a1 = var(), var a2 = var(), var a3 = var(), var a4 = var(), var a5 = var(),
var a6 = var(), var a7 = var(), var a8 = var(), var a9 = var(), var a10 = var())
{
  return (*((function<var(var, var, var, var)>*)r.data))(a1, a2, a3, a4);
}
var callVarFunc5(VarRef & r, var a1 = var(), var a2 = var(), var a3 = var(), var a4 = var(), var a5 = var(),
var a6 = var(), var a7 = var(), var a8 = var(), var a9 = var(), var a10 = var())
{
  return (*((function<var(var, var, var, var, var)>*)r.data))(a1, a2, a3, a4, a5);
}
var callVarFunc6(VarRef & r, var a1 = var(), var a2 = var(), var a3 = var(), var a4 = var(), var a5 = var(),
var a6 = var(), var a7 = var(), var a8 = var(), var a9 = var(), var a10 = var())
{
  return (*((function<var(var, var, var, var, var, var)>*)r.data))(a1, a2, a3, a4, a5, a6);
}
var callVarFunc7(VarRef & r, var a1 = var(), var a2 = var(), var a3 = var(), var a4 = var(), var a5 = var(),
var a6 = var(), var a7 = var(), var a8 = var(), var a9 = var(), var a10 = var())
{
  return (*((function<var(var, var, var, var, var, var, var)>*)r.data))(a1, a2, a3, a4, a5, a6, a7);
}
var callVarFunc8(VarRef & r, var a1 = var(), var a2 = var(), var a3 = var(), var a4 = var(), var a5 = var(),
var a6 = var(), var a7 = var(), var a8 = var(), var a9 = var(), var a10 = var())
{
  return (*((function<var(var, var, var, var, var, var, var, var)>*)r.data))(a1, a2, a3, a4, a5, a6, a7, a8);
}
var callVarFunc9(VarRef & r, var a1 = var(), var a2 = var(), var a3 = var(), var a4 = var(), var a5 = var(),
var a6 = var(), var a7 = var(), var a8 = var(), var a9 = var(), var a10 = var())
{
  return (*((function<var(var, var, var, var, var, var, var, var, var)>*)r.data))(a1, a2, a3, a4, a5, a6, a7, a8, a9);
}
var callVarFunc10(VarRef & r, var a1 = var(), var a2 = var(), var a3 = var(), var a4 = var(), var a5 = var(),
var a6 = var(), var a7 = var(), var a8 = var(), var a9 = var(), var a10 = var())
{
  return (*((function<var(var, var, var, var, var, var, var, var, var, var)>*)r.data))(a1, a2, a3, a4, a5, a6, a7, a8, a9, a10);
}






var(*callVarFunc[][11])(VarRef &, var, var, var, var, var, var, var, var, var, var)={
{
  callVoidFunc0,
  callVoidFunc1,
  callVoidFunc2,
  callVoidFunc3,
  callVoidFunc4,
  callVoidFunc5,
  callVoidFunc6,
  callVoidFunc7,
  callVoidFunc8,
  callVoidFunc9,
  callVoidFunc10
},
{
  callVarFunc0,
  callVarFunc1,
  callVarFunc2,
  callVarFunc3,
  callVarFunc4,
  callVarFunc5,
  callVarFunc6,
  callVarFunc7,
  callVarFunc8,
  callVarFunc9,
  callVarFunc10
}
};

#endif
