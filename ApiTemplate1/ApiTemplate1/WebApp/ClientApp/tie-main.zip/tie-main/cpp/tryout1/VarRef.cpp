#ifndef VARREF_CPP
#define VARREF_CPP
#include "VarRef.hpp"
VarRef::VarRef()
{
	t = VarType::Undefined;
	count = 0;
	data = 0;
}

#endif
