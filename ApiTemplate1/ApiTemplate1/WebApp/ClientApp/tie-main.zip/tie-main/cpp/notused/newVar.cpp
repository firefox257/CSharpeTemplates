#ifndef NEWVAR_CPP
#define NEWVAR_CPP
/*
void newVarUndefined(VarRef * & ref)
{
	VarRef & r = *ref;
  r.count = 0;
}
void newVarBool(VarRef * & ref)
{
	VarRef & r = *ref;
  r.count = 1;
  r.data = new bool;
}
void newVarChar(VarRef * & ref)
{
	VarRef & r = *ref;
  r.count = 1;
  r.data = new char;
}
void newVarInt8(VarRef * & ref)
{
	VarRef & r = *ref;
  r.count = 1;
  r.data = new int8_t;
}
void newVarUint8(VarRef * & ref)
{
	VarRef & r = *ref;
  r.count = 1;
  r.data = new uint8_t;
}
void newVarInt16(VarRef * & ref)
{
	VarRef & r = *ref;
  r.count = 1;
  r.data = new int16_t;
}
void newVarUint16(VarRef * & ref)
{
	VarRef & r = *ref;
  r.count = 1;
  r.data = new uint16_t;
}
void newVarInt32(VarRef * & ref)
{
	VarRef & r = *ref;
  r.count = 1;
  r.data = new int32_t;
}
void newVarUint32(VarRef * & ref)
{
	VarRef & r = *ref;
  r.count = 1;
  r.data = new uint32_t;
}
void newVarInt64(VarRef * & ref)
{
	VarRef & r = *ref;
  r.count = 1;
  r.data = new int64_t;
}
void newVarUint64(VarRef * & ref)
{
	VarRef & r = *ref;
  r.count = 1;
  r.data = new uint64_t;
}
void newVarFloat(VarRef * & ref)
{
	VarRef & r = *ref;
  r.count = 1;
  r.data = new float;
}
void newVarDouble(VarRef * & ref)
{
	VarRef & r = *ref;
  r.count = 1;
  r.data = new double;
}
void newVarString(VarRef * & ref)
{
	VarRef & r = *ref;
  r.count = 1;
  r.data = new string;
}
void newVarList(VarRef * & ref)
{
	VarRef & r = *ref;
  r.count = 1;
  r.data = new vector<var>;
}
void newVarMap(VarRef * & ref)
{
	VarRef & r = *ref;
  r.count = 1;
  r.data = new unordered_map<string, var>;
}
void newVarGetSet(VarRef * & ref)
{
	VarRef & r = *ref;
	todohere;
  r.count = 1;
  r.data = new VarGetSet;
}

////// functions




/////end functions





void(*newVar[])(VarRef * & ref) = {newVarUndefined,
	newVarBool, newVarChar,
	newVarInt8,
	newVarUint8,
	newVarInt16,
	newVarUint16,
	newVarInt32,
	newVarUint32,
	newVarInt64,
	newVarUint64,
	newVarFloat,
	newVarDouble,
	newVarString,
	newVarList,
	newVarMap,
	newVarGetSet};

////todo functions
*/

#endif
