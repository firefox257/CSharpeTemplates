#ifndef VAR_CPP
#define VAR_CPP
#include "var.hpp"
#include "VarRef.cpp"
#include "Exception.cpp"
#include "VarUndefinedOPerators.cpp"


var::var()
{

}



#endif
