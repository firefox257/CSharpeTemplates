#ifndef EXCEPTION_CPP
#define EXCEPTION_CPP

#include "Exception.hpp"
using namespace std;

/*
Exception::Exception(string msg = "", string fileName = "", int lineNumber = -1)
{
	Message = msg;
	FileName = fileName;
	LineNumber = lineNumber;
}
*/
#endif
